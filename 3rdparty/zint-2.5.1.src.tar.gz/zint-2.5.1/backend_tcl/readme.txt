    zint tcl binding readme
    -----------------------
    2014-06-30
    (C) Harald Oehlmann
    harald.oehlmann@users.sourceforge.net

What: tcl binding for zint bar code generator library

Build:
- MS-VC6 project file "zint_tcl.dsp" may be opened by the GUI.
- Linux/Unix build is no issue in principe but is not done jet

Usage:

load zint.dll
zint help

Most options are identical to the command line tool and are described in the
zint manual.

Demo:
The demo folder contains a minimal visual demo program.
